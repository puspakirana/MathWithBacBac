package com.example.dicegame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView brgapp = (ImageView)findViewById(R.id.brgapp);
        ImageView calc =(ImageView)findViewById(R.id.calculator);
        LinearLayout textsplash = (LinearLayout)findViewById(R.id.textsplash);
        LinearLayout texthome = (LinearLayout)findViewById(R.id.texthome);
        LinearLayout menus = (LinearLayout)findViewById(R.id.menus);

        Animation explore = AnimationUtils.loadAnimation(this, R.anim.explore);

        brgapp.animate().translationY(-2500).setDuration(800).setStartDelay(400);
        calc.animate().alpha(0).setDuration(500).setStartDelay(600);
        textsplash.animate().translationY(300).alpha(0).setDuration(500).setStartDelay(400);

        texthome.startAnimation(explore);
        menus.startAnimation(explore);

        menuHandler();

    }

    public void menuHandler()
    {
        LinearLayout add_act = (LinearLayout)findViewById(R.id.add_act);
        add_act.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent add_page = new Intent(MainActivity.this, addTheDice.class);
                startActivity(add_page);
            }
        });

        LinearLayout sub_act = (LinearLayout)findViewById(R.id.sub_act);
        sub_act.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sub_page = new Intent(MainActivity.this, subtractTheDice.class);
                startActivity(sub_page);
            }
        });

        LinearLayout mul_act = (LinearLayout)findViewById(R.id.mul_act);
        mul_act.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mul_page = new Intent(MainActivity.this, multiplyTheDice.class);
                startActivity(mul_page);
            }
        });

        LinearLayout div_act = (LinearLayout)findViewById(R.id.div_act);
        div_act.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent div_page = new Intent(MainActivity.this, divideTheDice.class);
                startActivity(div_page);
            }
        });

    }


}