package com.example.dicegame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;
import java.util.Random;

public class addTheDice extends AppCompatActivity {

    int value1, value2;
    int rollResult = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_the_dice);
        diceValue();
        startAddingGame();
    }

    public void startAddingGame()
    {
        Button checkAns = (Button)findViewById(R.id.checkAddition);

        //OVERBOX / TRANSPARENT BRG POP UP
        LinearLayout overbox = (LinearLayout) findViewById(R.id.overbox);

        //CORECT POP UP
        Button close_correct = (Button)findViewById(R.id.btn_close_correct);
        LinearLayout popup_correct = (LinearLayout) findViewById(R.id.popup_correct);
        ImageView icon_correct = (ImageView)findViewById(R.id.popicon_correct);

        //WRONG POP UP
        Button btn_tryagain = (Button)findViewById(R.id.btn_tryagain);
        LinearLayout popup_wrong = (LinearLayout) findViewById(R.id.popup_wrong);
        ImageView icon_wrong = (ImageView)findViewById(R.id.popicon_wrong);

        //ANIMATION
        Animation fromsmall = AnimationUtils.loadAnimation(this, R.anim.fromsmall);
        Animation fromnothing = AnimationUtils.loadAnimation(this, R.anim.fromnothing);
        Animation foricon = AnimationUtils.loadAnimation(this, R.anim.foricon);
        Animation togo = AnimationUtils.loadAnimation(this, R.anim.togo);

        //Set pop up NOT VISIBLE
        overbox.setAlpha(0);
        //correct
        popup_correct.setVisibility(View.GONE);
        popup_correct.setAlpha(0);
        icon_correct.setVisibility(View.GONE);
        //wrong
        popup_wrong.setVisibility(View.GONE);
        popup_wrong.setAlpha(0);
        icon_wrong.setVisibility(View.GONE);

        checkAns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText inputAns = (EditText) findViewById(R.id.answerAdd);
                String ans = inputAns.getText().toString();

                if(ans.isEmpty())
                {
                    inputAns.setError("Input is required");
                }
                else
                {
                    int answer = Integer.parseInt(ans);

                    if(answer == rollResult)
                    {
                        //Delete text in input box
                        inputAns.setText("");

                        //overbox appear
                        overbox.setAlpha(1);
                        overbox.startAnimation(fromnothing);

                        //pop up correct appear
                        popup_correct.setVisibility(View.VISIBLE);
                        popup_correct.setAlpha(1);
                        popup_correct.startAnimation(fromsmall);

                        //Icon appear
                        icon_correct.setVisibility(View.VISIBLE);
                        icon_correct.startAnimation(foricon);

                        //Close Button in Pop Up
                        close_correct.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                overbox.setAlpha(0);
                                popup_correct.startAnimation(togo);
                                icon_correct.startAnimation(togo);
                                icon_correct.setVisibility(View.GONE);
                                popup_correct.setVisibility(View.GONE);
                                ViewCompat.animate(popup_correct).setStartDelay(1000).alpha(0).start();

                                diceValue();
                            }
                        });

                    }
                    else
                    {
                        //Delete text in input box
                        inputAns.setText("");

                        //overbox appear
                        overbox.setAlpha(1);
                        overbox.startAnimation(fromnothing);

                        //pop up correct appear
                        popup_wrong.setVisibility(View.VISIBLE);
                        popup_wrong.setAlpha(1);
                        popup_wrong.startAnimation(fromsmall);

                        //Icon appear
                        icon_wrong.setVisibility(View.VISIBLE);
                        icon_wrong.startAnimation(foricon);

                        btn_tryagain.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                overbox.setAlpha(0);
                                popup_wrong.startAnimation(togo);
                                icon_wrong.startAnimation(togo);
                                icon_wrong.setVisibility(View.GONE);
                                popup_wrong.setVisibility(View.GONE);
                                ViewCompat.animate(popup_wrong).setStartDelay(1000).alpha(0).start();
                            }
                        });

                    }
                }

            }
        });

    }

    public void diceValue()
    {
        Random rand = new Random();
        Animation animateDice = AnimationUtils.loadAnimation(this, R.anim.rotate);

        //Dice Image
        ImageView img1 = (ImageView)findViewById(R.id.dice1Add);
        ImageView img2 = (ImageView)findViewById(R.id.dice2Add);

        //Randomize dice
        value1 = rand.nextInt(6)+1;
        value2 = rand.nextInt(6)+1;

        //Addition of 2 dice
        rollResult = value1+value2;


        img1.startAnimation(animateDice);
        //Change Image
        switch(value1)
        {
            case 1:
                img1.setImageResource(R.drawable.dice_1);
                break;
            case 2:
                img1.setImageResource(R.drawable.dice_2);
                break;
            case 3:
                img1.setImageResource(R.drawable.dice_3);
                break;
            case 4:
                img1.setImageResource(R.drawable.dice_4);
                break;
            case 5:
                img1.setImageResource(R.drawable.dice_5);
                break;
            case 6:
                img1.setImageResource(R.drawable.dice_6);
                break;
        }
        img2.startAnimation(animateDice);
        switch(value2)
        {
            case 1:
                img2.setImageResource(R.drawable.dice_1);
                break;
            case 2:
                img2.setImageResource(R.drawable.dice_2);
                break;
            case 3:
                img2.setImageResource(R.drawable.dice_3);
                break;
            case 4:
                img2.setImageResource(R.drawable.dice_4);
                break;
            case 5:
                img2.setImageResource(R.drawable.dice_5);
                break;
            case 6:
                img2.setImageResource(R.drawable.dice_6);
                break;
        }


    }

}