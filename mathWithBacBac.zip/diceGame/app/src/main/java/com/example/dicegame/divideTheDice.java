package com.example.dicegame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Random;

public class divideTheDice extends AppCompatActivity {

    int value1, value2;
    double rollResult = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_divide_the_dice);
        diceValue();
        startDividingGame();
    }


    public void startDividingGame()
    {
        Button checkAns = (Button)findViewById(R.id.checkDivision);

        //OVERBOX / TRANSPARENT BRG POP UP
        LinearLayout overboxdiv = (LinearLayout) findViewById(R.id.overboxdiv);

        //CORECT POP UP
        Button close_correctdiv = (Button)findViewById(R.id.btn_close_correctdiv);
        LinearLayout popup_correctdiv = (LinearLayout) findViewById(R.id.popup_correctdiv);
        ImageView icon_correctdiv = (ImageView)findViewById(R.id.popicon_correctdiv);

        //WRONG POP UP
        Button btn_tryagaindiv = (Button)findViewById(R.id.btn_tryagaindiv);
        LinearLayout popup_wrongdiv = (LinearLayout) findViewById(R.id.popup_wrongdiv);
        ImageView icon_wrongdiv = (ImageView)findViewById(R.id.popicon_wrongdiv);

        //ANIMATION
        Animation fromsmall = AnimationUtils.loadAnimation(this, R.anim.fromsmall);
        Animation fromnothing = AnimationUtils.loadAnimation(this, R.anim.fromnothing);
        Animation foricon = AnimationUtils.loadAnimation(this, R.anim.foricon);
        Animation togo = AnimationUtils.loadAnimation(this, R.anim.togo);

        //Set pop up NOT VISIBLE
        overboxdiv.setAlpha(0);
        //correct
        popup_correctdiv.setVisibility(View.GONE);
        popup_correctdiv.setAlpha(0);
        icon_correctdiv.setVisibility(View.GONE);
        //wrong
        popup_wrongdiv.setVisibility(View.GONE);
        popup_wrongdiv.setAlpha(0);
        icon_wrongdiv.setVisibility(View.GONE);

        checkAns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText inputAns = (EditText) findViewById(R.id.answerAdd);
                String ans = inputAns.getText().toString();

                if(ans.isEmpty())
                {
                    inputAns.setError("Input is required");
                }
                else
                {
                    double answer = Double.parseDouble(ans);

                    if(answer == rollResult)
                    {
                        //Delete text in input box
                        inputAns.setText("");

                        //overbox appear
                        overboxdiv.setAlpha(1);
                        overboxdiv.startAnimation(fromnothing);

                        //pop up correct appear
                        popup_correctdiv.setVisibility(View.VISIBLE);
                        popup_correctdiv.setAlpha(1);
                        popup_correctdiv.startAnimation(fromsmall);

                        //Icon appear
                        icon_correctdiv.setVisibility(View.VISIBLE);
                        icon_correctdiv.startAnimation(foricon);

                        //Close Button in Pop Up
                        close_correctdiv.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                overboxdiv.setAlpha(0);
                                popup_correctdiv.startAnimation(togo);
                                icon_correctdiv.startAnimation(togo);
                                icon_correctdiv.setVisibility(View.GONE);
                                popup_correctdiv.setVisibility(View.GONE);
                                ViewCompat.animate(popup_correctdiv).setStartDelay(1000).alpha(0).start();

                                diceValue();
                            }
                        });

                    }
                    else
                    {
                        //Delete text in input box
                        inputAns.setText("");

                        //overbox appear
                        overboxdiv.setAlpha(1);
                        overboxdiv.startAnimation(fromnothing);

                        //pop up correct appear
                        popup_wrongdiv.setVisibility(View.VISIBLE);
                        popup_wrongdiv.setAlpha(1);
                        popup_wrongdiv.startAnimation(fromsmall);

                        //Icon appear
                        icon_wrongdiv.setVisibility(View.VISIBLE);
                        icon_wrongdiv.startAnimation(foricon);

                        btn_tryagaindiv.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                overboxdiv.setAlpha(0);
                                popup_wrongdiv.startAnimation(togo);
                                icon_wrongdiv.startAnimation(togo);
                                icon_wrongdiv.setVisibility(View.GONE);
                                popup_wrongdiv.setVisibility(View.GONE);
                                ViewCompat.animate(popup_wrongdiv).setStartDelay(1000).alpha(0).start();
                            }
                        });
                    }

                }


            }
        });

    }

    public void diceValue()
    {
        Random rand = new Random();
        Animation animateDice = AnimationUtils.loadAnimation(this, R.anim.rotate);

        //Dice Image
        ImageView img1 = (ImageView)findViewById(R.id.dice1Add);
        ImageView img2 = (ImageView)findViewById(R.id.dice2Add);

        //Randomize dice
        value1 = rand.nextInt(6)+1;
        value2 = rand.nextInt(6)+1;

        //Division of 2 dice
        double result = (double)value1/(double)value2;
        DecimalFormat df = new DecimalFormat("#.#");
        df.setRoundingMode(RoundingMode.DOWN); //ROUNDED DOWN
        rollResult = Double.parseDouble(df.format(result));


        img1.startAnimation(animateDice);
        //Change Image
        switch(value1)
        {
            case 1:
                img1.setImageResource(R.drawable.dice_1);
                break;
            case 2:
                img1.setImageResource(R.drawable.dice_2);
                break;
            case 3:
                img1.setImageResource(R.drawable.dice_3);
                break;
            case 4:
                img1.setImageResource(R.drawable.dice_4);
                break;
            case 5:
                img1.setImageResource(R.drawable.dice_5);
                break;
            case 6:
                img1.setImageResource(R.drawable.dice_6);
                break;
        }
        img2.startAnimation(animateDice);
        switch(value2)
        {
            case 1:
                img2.setImageResource(R.drawable.dice_1);
                break;
            case 2:
                img2.setImageResource(R.drawable.dice_2);
                break;
            case 3:
                img2.setImageResource(R.drawable.dice_3);
                break;
            case 4:
                img2.setImageResource(R.drawable.dice_4);
                break;
            case 5:
                img2.setImageResource(R.drawable.dice_5);
                break;
            case 6:
                img2.setImageResource(R.drawable.dice_6);
                break;
        }


    }

}