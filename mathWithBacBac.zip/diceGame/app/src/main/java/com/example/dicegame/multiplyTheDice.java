package com.example.dicegame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;
import java.util.Random;

public class multiplyTheDice extends AppCompatActivity {

    int value1, value2;
    int rollResult = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiply_the_dice);
        diceValue();
        startMultiplyingGame();
    }

    public void startMultiplyingGame()
    {
        Button checkAns = (Button)findViewById(R.id.checkMultipication);

        //OVERBOX / TRANSPARENT BRG POP UP
        LinearLayout overboxmul = (LinearLayout) findViewById(R.id.overboxmul);

        //CORECT POP UP
        Button close_correctmul = (Button)findViewById(R.id.btn_close_correctmul);
        LinearLayout popup_correctmul = (LinearLayout) findViewById(R.id.popup_correctmul);
        ImageView icon_correctmul = (ImageView)findViewById(R.id.popicon_correctmul);

        //WRONG POP UP
        Button btn_tryagainmul = (Button)findViewById(R.id.btn_tryagainmul);
        LinearLayout popup_wrongmul = (LinearLayout) findViewById(R.id.popup_wrongmul);
        ImageView icon_wrongmul = (ImageView)findViewById(R.id.popicon_wrongmul);

        //ANIMATION
        Animation fromsmall = AnimationUtils.loadAnimation(this, R.anim.fromsmall);
        Animation fromnothing = AnimationUtils.loadAnimation(this, R.anim.fromnothing);
        Animation foricon = AnimationUtils.loadAnimation(this, R.anim.foricon);
        Animation togo = AnimationUtils.loadAnimation(this, R.anim.togo);

        //Set pop up NOT VISIBLE
        overboxmul.setAlpha(0);
        //correct
        popup_correctmul.setVisibility(View.GONE);
        popup_correctmul.setAlpha(0);
        icon_correctmul.setVisibility(View.GONE);
        //wrong
        popup_wrongmul.setVisibility(View.GONE);
        popup_wrongmul.setAlpha(0);
        icon_wrongmul.setVisibility(View.GONE);

        checkAns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText inputAns = (EditText) findViewById(R.id.answerAdd);
                String ans = inputAns.getText().toString();
                if(ans.isEmpty())
                {
                    inputAns.setError("Input is required");
                }
                else
                {
                    int answer = Integer.parseInt(ans);

                    if(answer == rollResult)
                    {
                        //Delete text in input box
                        inputAns.setText("");

                        //overbox appear
                        overboxmul.setAlpha(1);
                        overboxmul.startAnimation(fromnothing);

                        //pop up correct appear
                        popup_correctmul.setVisibility(View.VISIBLE);
                        popup_correctmul.setAlpha(1);
                        popup_correctmul.startAnimation(fromsmall);

                        //Icon appear
                        icon_correctmul.setVisibility(View.VISIBLE);
                        icon_correctmul.startAnimation(foricon);

                        //Close Button in Pop Up
                        close_correctmul.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                overboxmul.setAlpha(0);
                                popup_correctmul.startAnimation(togo);
                                icon_correctmul.startAnimation(togo);
                                icon_correctmul.setVisibility(View.GONE);
                                popup_correctmul.setVisibility(View.GONE);
                                ViewCompat.animate(popup_correctmul).setStartDelay(1000).alpha(0).start();

                                diceValue();
                            }
                        });

                    }
                    else
                    {
                        //Delete text in input box
                        inputAns.setText("");

                        //overbox appear
                        overboxmul.setAlpha(1);
                        overboxmul.startAnimation(fromnothing);

                        //pop up correct appear
                        popup_wrongmul.setVisibility(View.VISIBLE);
                        popup_wrongmul.setAlpha(1);
                        popup_wrongmul.startAnimation(fromsmall);

                        //Icon appear
                        icon_wrongmul.setVisibility(View.VISIBLE);
                        icon_wrongmul.startAnimation(foricon);

                        btn_tryagainmul.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                overboxmul.setAlpha(0);
                                popup_wrongmul.startAnimation(togo);
                                icon_wrongmul.startAnimation(togo);
                                icon_wrongmul.setVisibility(View.GONE);
                                popup_wrongmul.setVisibility(View.GONE);
                                ViewCompat.animate(popup_wrongmul).setStartDelay(1000).alpha(0).start();
                            }
                        });
                    }
                }

            }
        });

    }

    public void diceValue()
    {
        Random rand = new Random();
        Animation animateDice = AnimationUtils.loadAnimation(this, R.anim.rotate);

        //Dice Image
        ImageView img1 = (ImageView)findViewById(R.id.dice1Add);
        ImageView img2 = (ImageView)findViewById(R.id.dice2Add);

        //Randomize dice
        value1 = rand.nextInt(6)+1;
        value2 = rand.nextInt(6)+1;

        //Multiplication of 2 dice
        rollResult = value1*value2;


        img1.startAnimation(animateDice);
        //Change Image
        switch(value1)
        {
            case 1:
                img1.setImageResource(R.drawable.dice_1);
                break;
            case 2:
                img1.setImageResource(R.drawable.dice_2);
                break;
            case 3:
                img1.setImageResource(R.drawable.dice_3);
                break;
            case 4:
                img1.setImageResource(R.drawable.dice_4);
                break;
            case 5:
                img1.setImageResource(R.drawable.dice_5);
                break;
            case 6:
                img1.setImageResource(R.drawable.dice_6);
                break;
        }
        img2.startAnimation(animateDice);
        switch(value2)
        {
            case 1:
                img2.setImageResource(R.drawable.dice_1);
                break;
            case 2:
                img2.setImageResource(R.drawable.dice_2);
                break;
            case 3:
                img2.setImageResource(R.drawable.dice_3);
                break;
            case 4:
                img2.setImageResource(R.drawable.dice_4);
                break;
            case 5:
                img2.setImageResource(R.drawable.dice_5);
                break;
            case 6:
                img2.setImageResource(R.drawable.dice_6);
                break;
        }


    }

}