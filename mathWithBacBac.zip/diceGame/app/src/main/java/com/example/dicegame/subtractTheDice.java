package com.example.dicegame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;
import java.util.Random;

public class subtractTheDice extends AppCompatActivity{

    int value1, value2;
    int rollResult = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subtract_the_dice);
        diceValue();
        startSubtractingGame();
    }


    public void startSubtractingGame()
    {
        Button checkAns = (Button)findViewById(R.id.checkSubtraction);

        //OVERBOX / TRANSPARENT BRG POP UP
        LinearLayout overboxsub = (LinearLayout) findViewById(R.id.overboxsub);

        //CORECT POP UP
        Button close_correctsub = (Button)findViewById(R.id.btn_close_correctsub);
        LinearLayout popup_correctsub = (LinearLayout) findViewById(R.id.popup_correctsub);
        ImageView icon_correctsub = (ImageView)findViewById(R.id.popicon_correctsub);

        //WRONG POP UP
        Button btn_tryagainsub = (Button)findViewById(R.id.btn_tryagainsub);
        LinearLayout popup_wrongsub = (LinearLayout) findViewById(R.id.popup_wrongsub);
        ImageView icon_wrongsub = (ImageView)findViewById(R.id.popicon_wrongsub);


        //ANIMATION
        Animation fromsmall = AnimationUtils.loadAnimation(this, R.anim.fromsmall);
        Animation fromnothing = AnimationUtils.loadAnimation(this, R.anim.fromnothing);
        Animation foricon = AnimationUtils.loadAnimation(this, R.anim.foricon);
        Animation togo = AnimationUtils.loadAnimation(this, R.anim.togo);

        //Set pop up NOT VISIBLE
        overboxsub.setAlpha(0);
        //correct
        popup_correctsub.setVisibility(View.GONE);
        popup_correctsub.setAlpha(0);
        icon_correctsub.setVisibility(View.GONE);
        //wrong
        popup_wrongsub.setVisibility(View.GONE);
        popup_wrongsub.setAlpha(0);
        icon_wrongsub.setVisibility(View.GONE);

        checkAns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText inputAns = (EditText) findViewById(R.id.answerAdd);
                String ans = inputAns.getText().toString();

                if(ans.isEmpty())
                {
                    inputAns.setError("Input is required");
                }
                else
                {
                    int answer = Integer.parseInt(ans);

                    if(answer == rollResult)
                    {
                        //Delete text in input box
                        inputAns.setText("");

                        //overbox appear
                        overboxsub.setAlpha(1);
                        overboxsub.startAnimation(fromnothing);

                        //pop up correct appear
                        popup_correctsub.setVisibility(View.VISIBLE);
                        popup_correctsub.setAlpha(1);
                        popup_correctsub.startAnimation(fromsmall);

                        //Icon appear
                        icon_correctsub.setVisibility(View.VISIBLE);
                        icon_correctsub.startAnimation(foricon);

                        //Close Button in Pop Up
                        close_correctsub.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                overboxsub.setAlpha(0);
                                popup_correctsub.startAnimation(togo);
                                icon_correctsub.startAnimation(togo);
                                icon_correctsub.setVisibility(View.GONE);
                                popup_correctsub.setVisibility(View.GONE);
                                ViewCompat.animate(popup_correctsub).setStartDelay(1000).alpha(0).start();

                                diceValue();
                            }
                        });
                    }
                    else
                    {
                        //Delete text in input box
                        inputAns.setText("");

                        //overbox appear
                        overboxsub.setAlpha(1);
                        overboxsub.startAnimation(fromnothing);

                        //pop up correct appear
                        popup_wrongsub.setVisibility(View.VISIBLE);
                        popup_wrongsub.setAlpha(1);
                        popup_wrongsub.startAnimation(fromsmall);

                        //Icon appear
                        icon_wrongsub.setVisibility(View.VISIBLE);
                        icon_wrongsub.startAnimation(foricon);

                        btn_tryagainsub.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                overboxsub.setAlpha(0);
                                popup_wrongsub.startAnimation(togo);
                                icon_wrongsub.startAnimation(togo);
                                icon_wrongsub.setVisibility(View.GONE);
                                popup_wrongsub.setVisibility(View.GONE);
                                ViewCompat.animate(popup_wrongsub).setStartDelay(1000).alpha(0).start();
                            }
                        });
                    }
                }

            }
        });

    }

    public void diceValue()
    {
        Random rand = new Random();
        Animation animateDice = AnimationUtils.loadAnimation(this, R.anim.rotate);

        //Dice Image
        ImageView img1 = (ImageView)findViewById(R.id.dice1Add);
        ImageView img2 = (ImageView)findViewById(R.id.dice2Add);

        //Randomize dice
        value1 = rand.nextInt(6)+1;
        value2 = rand.nextInt(6)+1;

        //Subtraction of 2 dice
        rollResult = value1-value2;


        img1.startAnimation(animateDice);
        //Change Image
        switch(value1)
        {
            case 1:
                img1.setImageResource(R.drawable.dice_1);
                break;
            case 2:
                img1.setImageResource(R.drawable.dice_2);
                break;
            case 3:
                img1.setImageResource(R.drawable.dice_3);
                break;
            case 4:
                img1.setImageResource(R.drawable.dice_4);
                break;
            case 5:
                img1.setImageResource(R.drawable.dice_5);
                break;
            case 6:
                img1.setImageResource(R.drawable.dice_6);
                break;
        }
        img2.startAnimation(animateDice);
        switch(value2)
        {
            case 1:
                img2.setImageResource(R.drawable.dice_1);
                break;
            case 2:
                img2.setImageResource(R.drawable.dice_2);
                break;
            case 3:
                img2.setImageResource(R.drawable.dice_3);
                break;
            case 4:
                img2.setImageResource(R.drawable.dice_4);
                break;
            case 5:
                img2.setImageResource(R.drawable.dice_5);
                break;
            case 6:
                img2.setImageResource(R.drawable.dice_6);
                break;
        }


    }


}